package pagerank;


public class Main {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello world!");
        if (args.length < 1) {
            System.exit(1);
        }

        String path = args[0];
        System.out.println("Loading graph from: " + path);
        GraphLoader.Graph g = GraphLoader.loadGoogleWebGraph(path);
        System.out.println("Graph loaded. maxNodeId=" + g.maxNodeId + " activeNodes=" + g.numNodes);

        Benchmark.run(g);
        System.out.println("Top 20 salavati in Top20.txt");
    }
}