package pagerank;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

public class PageRankParallel {

    public static double[] compute(GraphLoader.Graph g, double d,
                                   int maxIterations, double tolerance,
                                   int numThreads) throws InterruptedException, ExecutionException {

        int n = g.maxNodeId + 1;
        double[] rank = new double[n];
        double[] rankNew = new double[n];

        int N = 0;
        boolean[] active = new boolean[n];
        for (int v = 0; v < n; v++) {
            if (g.outDegree[v] > 0 || g.inNeighbors[v].length > 0) {
                active[v] = true;
                N++;
            }
        }

        double init = 1.0 / N;
        for (int v = 0; v < n; v++) {
            if (active[v]) {
                rank[v] = init;
            }
        }

        double base = (1.0 - d) / N;

        ExecutorService executor = Executors.newFixedThreadPool(numThreads);

        List<int[]> ranges = splitRange(n, numThreads);

        for (int iter = 0; iter < maxIterations; iter++) {
            Arrays.fill(rankNew, 0.0);

            List<Future<Double>> futures = new ArrayList<>();

            for (int[] range : ranges) {
                int start = range[0];
                int end = range[1];

                double[] finalRankNew = rankNew;
                double[] finalRank = rank;
                Callable<Double> task = () -> {
                    double localDiff = 0.0;
                    for (int v = start; v < end; v++) {
                        if (!active[v]) continue;
                        double sum = 0.0;
                        int[] inNeigh = g.inNeighbors[v];
                        for (int u : inNeigh) {
                            int outDeg = g.outDegree[u];
                            if (outDeg > 0) {
                                sum += finalRank[u] / outDeg;
                            }
                        }
                        double newVal = base + d * sum;
                        localDiff += Math.abs(newVal - finalRank[v]);
                        finalRankNew[v] = newVal;
                    }
                    return localDiff;
                };

                futures.add(executor.submit(task));
            }

            double diff = 0.0;
            for (Future<Double> f : futures) {
                diff += f.get();
            }

            double[] tmp = rank;
            rank = rankNew;
            rankNew = tmp;

            if (diff < tolerance) {
                break;
            }
        }

        executor.shutdown();
        return rank;
    }

    private static List<int[]> splitRange(int to, int numParts) {
        List<int[]> ranges = new ArrayList<>();
        int base = to / numParts;
        int rem = to % numParts;

        int start = 0;
        for (int i = 0; i < numParts; i++) {
            int size = base + (i < rem ? 1 : 0);
            int end = start + size;
            ranges.add(new int[]{start, end});
            start = end;
        }
        return ranges;
    }
}