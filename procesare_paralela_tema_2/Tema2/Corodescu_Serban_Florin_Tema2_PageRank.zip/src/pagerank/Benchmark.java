package pagerank;

public class Benchmark {

    public static void run(GraphLoader.Graph g) throws Exception {
        double d = 0.85;
        int maxIterations = 10;
        double tolerance = 1e-6;

        long t1Start = System.currentTimeMillis();
//        double[] rank1 = PageRankParallel.compute(g, d, maxIterations, tolerance, 1);
        long t1End = System.currentTimeMillis();
        long t1 = t1End - t1Start;
        System.out.println("Parallel PR cu un 1 thread: " + t1 + " ms");

        long t8Start = System.currentTimeMillis();
        double[] rank8 = PageRankParallel.compute(g, d, maxIterations, tolerance, 8);
        long t8End = System.currentTimeMillis();
        long t8 = t8End - t8Start;
        System.out.println("Parallel PR cu 8 threads: " + t8 + " ms");

        double speedup = (double) t1 / (double) t8;
        System.out.println("Speedup (1 / 8 threads): " + speedup);

        Utils.writeTopK(rank8, 20, "Top20.txt");
    }
}