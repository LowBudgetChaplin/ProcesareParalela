package pagerank;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Utils {

    public static void writeTopK(double[] rank, int k, String outputPath) throws IOException {
        List<NodeRank> list = new ArrayList<>();
        for (int i = 0; i < rank.length; i++) {
            if (rank[i] > 0) {
                list.add(new NodeRank(i, rank[i]));
            }
        }

        list.sort((a, b) -> Double.compare(b.score, a.score));

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputPath))) {
            for (int i = 0; i < Math.min(k, list.size()); i++) {
                NodeRank nr = list.get(i);
                bw.write(nr.nodeId + " " + nr.score);
                bw.newLine();
            }
        }
    }

    private static class NodeRank {
        int nodeId;
        double score;

        NodeRank(int nodeId, double score) {
            this.nodeId = nodeId;
            this.score = score;
        }
    }
}
