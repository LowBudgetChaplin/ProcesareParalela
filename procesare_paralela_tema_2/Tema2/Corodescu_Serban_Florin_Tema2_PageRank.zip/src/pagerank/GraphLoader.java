package pagerank;

import java.io.*;
import java.util.*;

public class GraphLoader {

    public static class Graph {
        public final int numNodes;
        public final int maxNodeId;
        public final int[][] inNeighbors;
        public final int[] outDegree;

        public Graph(int numNodes, int maxNodeId, int[][] inNeighbors, int[] outDegree) {
            this.numNodes = numNodes;
            this.maxNodeId = maxNodeId;
            this.inNeighbors = inNeighbors;
            this.outDegree = outDegree;
        }
    }

    public static Graph loadGoogleWebGraph(String path) throws IOException {
        int maxNodeId = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("#")) continue;
                String[] parts = line.trim().split("\\s+");
                if (parts.length < 2) continue;

                int u = Integer.parseInt(parts[0]);
                int v = Integer.parseInt(parts[1]);
                if (u > maxNodeId) maxNodeId = u;
                if (v > maxNodeId) maxNodeId = v;
            }
        }

        int[] outDegree = new int[maxNodeId + 1];
        List<List<Integer>> inNeighborsList = new ArrayList<>(maxNodeId + 1);
        for (int i = 0; i <= maxNodeId; i++) {
            inNeighborsList.add(new ArrayList<>());
        }

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("#")) continue;
                String[] parts = line.trim().split("\\s+");
                if (parts.length < 2) continue;

                int u = Integer.parseInt(parts[0]);
                int v = Integer.parseInt(parts[1]);

                outDegree[u]++;
                inNeighborsList.get(v).add(u);
            }
        }

        int[][] inNeighbors = new int[maxNodeId + 1][];
        int numNodes = 0;
        for (int v = 0; v <= maxNodeId; v++) {
            List<Integer> list = inNeighborsList.get(v);
            if (!list.isEmpty() || outDegree[v] > 0) {
                numNodes++;
            }
            inNeighbors[v] = list.stream().mapToInt(Integer::intValue).toArray();
        }

        return new Graph(numNodes, maxNodeId, inNeighbors, outDegree);
    }
}